package org.bhavayademo.beans;

/**
 * Description.
 *
 * @author Parwinder Sekhon
 * @version $Revision: 1.1 $
 */
public abstract class InstrumentRating extends org.bhavaya.beans.Bean {
}
