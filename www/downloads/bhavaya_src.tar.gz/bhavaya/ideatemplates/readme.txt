Live Templates for IntelliJ Idea
--------------------------------

To use any of these, copy the file to your

"C:\Documents and Settings\<username>\.IntelliJIdea50\config\templates"

directory and restart IDEA.
