package org.bhavaya.ui;

import foxtrot.ConcurrentWorker;
import foxtrot.Job;
import foxtrot.pumps.EventFilter;
import foxtrot.pumps.EventFilterable;
import org.bhavaya.util.Log;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.util.Map;
import java.util.HashMap;

/**
 * Warning.  This class is fundamentally flawed in design!!!
 *
 * @author Brendon Mclean
 * @author Andrew J. Dean
 * @version $Revision: 1.4 $
 */
public class OwnerModalDialog extends JDialog {
    private static final Log log = Log.getCategory(OwnerModalDialog.class);

    private static ModalFilter modalFilter = new ModalFilter();

    private Object taskLock = new Object();


    public OwnerModalDialog(Frame owner, String title) throws HeadlessException {
        super(owner, title, false);
    }

    public OwnerModalDialog(Dialog owner, String title) throws HeadlessException {
        super(owner, title, false);
    }

    public void show() {
        startFilteringEvents();
        super.show();
        waitUntilHidden();
        stopFilteringEvents();
    }

    private void waitUntilHidden() {
        try {
            ConcurrentWorker.post(new Job() {
                public Object run() {
                    synchronized (taskLock) {
                        try {
                            taskLock.wait();
                            if (log.isDebug())log.debug("Dialog Woken up");
                        } catch (InterruptedException e) {
                            if (log.isDebug())log.debug("Interrupted whilst waiting");
                        }
                    }
                    return null;
                }
            });
        } catch (Exception e) {
        }
    }

    public void hide() {
        super.hide();

        synchronized (taskLock) {
            taskLock.notifyAll();
        }
        if (log.isDebug())log.debug("Dialog hidden - notifying");
    }

    public void setModal(boolean modal) {
        // By nature these are always modal, but the underlying JDialog must not be
        if (!modal) log.error("You cannot setModal(false) on an OwnerModalDialog!");
    }

    private void startFilteringEvents() {
        if (log.isDebug())log.debug("startFilteringEvents");
        modalFilter.addModalLock(getOwner(), this);
    }

    private void stopFilteringEvents() {
        if (log.isDebug())log.debug("stopFilteringEvents");
        modalFilter.removeModalLock(getOwner());
    }

    private static class ModalFilter implements EventFilter {
        private EventFilter superFilter;
        private Map ownerToDialogMap = new HashMap();

        private ModalFilter() {
        }

        public void addModalLock(Window owner, OwnerModalDialog dialog) {
            if (ownerToDialogMap.size() == 0) {
                EventFilterable eventFilterable = ((EventFilterable) ConcurrentWorker.getEventPump());
                superFilter = eventFilterable.getEventFilter();
                eventFilterable.setEventFilter(this);
            }
            ownerToDialogMap.put(owner, dialog);
        }

        public void removeModalLock(Window owner) {
            ownerToDialogMap.remove(owner);
            if (ownerToDialogMap.size()==0) {
                EventFilterable eventFilterable = ((EventFilterable) ConcurrentWorker.getEventPump());
                eventFilterable.setEventFilter(superFilter);
            }
        }

        public boolean accept(AWTEvent event) {
            OwnerModalDialog dialog = (OwnerModalDialog) ownerToDialogMap.get(event.getSource());
            if (dialog != null) {
                boolean eventTypeBlocked = eventTypeBlocked(event);
                if (eventTypeBlocked || windowEventRequiresAction(event)) {
                    dialog.toFront();
                }
                return !eventTypeBlocked;
            }
            return superFilter != null ? superFilter.accept(event) : true;
        }

        private boolean eventTypeBlocked(AWTEvent event) {
            return event instanceof KeyEvent || mouseClickEvent(event);
        }

        private boolean mouseClickEvent(AWTEvent event) {
            if (!(event instanceof MouseEvent)) return false;
            // Wee!  Look at me!  I feel like a C programmer.  Tie-die tshirts are cool!
            switch (event.getID()) {
                case MouseEvent.MOUSE_CLICKED:
                case MouseEvent.MOUSE_PRESSED:
                case MouseEvent.MOUSE_RELEASED:
                    return true;
                default:
                    return false;
            }
        }

        private boolean windowEventRequiresAction(AWTEvent event) {
            if (!(event instanceof WindowEvent)) return false;
            return event.getID() == WindowEvent.WINDOW_ACTIVATED
                    || event.getID() == WindowEvent.WINDOW_GAINED_FOCUS;
        }
    }


    public static void main(String[] args) throws IllegalAccessException, UnsupportedLookAndFeelException, InstantiationException, ClassNotFoundException {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

        for (int i = 0; i < 2; i++) {
            final JFrame frame = new JFrame();
            frame.getContentPane().add(new JButton(new AbstractAction("Dialog") {
                public void actionPerformed(ActionEvent e) {
                    System.out.println("About to show dialog");
                    JDialog dialog = new OwnerModalDialog(frame, "testD");
                    dialog.getContentPane().add(new JButton("Test"));
                    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                    dialog.pack();
                    dialog.show();
                    System.out.println("Closed Dialog");
                }
            }));
            frame.pack();
            frame.show();
        }
    }
}
