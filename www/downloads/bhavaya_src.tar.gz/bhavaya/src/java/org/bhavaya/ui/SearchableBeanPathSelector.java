/* Copyright (C) 2000-2003 The Software Conservancy as Trustee.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Nothing in this notice shall be deemed to grant any rights to trademarks,
 * copyrights, patents, trade secrets or any other intellectual property of the
 * licensor or any contributor except as expressly stated herein. No patent
 * license is granted separate from the Software, for code that you delete from
 * the Software, or for combinations of the Software with other software or
 * hardware.
 */

package org.bhavaya.ui;

import org.bhavaya.collection.IndexedSet;
import org.bhavaya.ui.table.BeanCollectionTableModel;
import org.bhavaya.util.*;
import org.bhavaya.util.TaskQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * @author Daniel van Enckevort
 * @version $Revision: 1.6 $
 */
public class SearchableBeanPathSelector extends JPanel {
    private static final ImageIcon CLEAR_ICON = new ImageIcon(IOUtilities.getResource("clear.png"));

    private static boolean quickSearchAcceptSubstring = false;

    private static final int MAX_SEARCH_DEPTH = 7;
    private static final HashSet navigationKeyCodeSet = new HashSet(Arrays.asList(new Object[]{
        new Integer(KeyEvent.VK_ENTER),
        new Integer(KeyEvent.VK_UP), new Integer(KeyEvent.VK_DOWN), new Integer(KeyEvent.VK_LEFT), new Integer(KeyEvent.VK_RIGHT),
        new Integer(KeyEvent.VK_HOME), new Integer(KeyEvent.VK_END),
        new Integer(KeyEvent.VK_PAGE_DOWN), new Integer(KeyEvent.VK_PAGE_UP)}));


    private BeanPathSelector beanPathSelector;
    private SearchField searchBox;
    private SearchResults searchResults;
    private CardPanel treeOrList;
    private ArrayList flattenedTree;
    private SearchResultsTreeModel searchResultsModel;
    private JTextField dummySearchBox;
    private CardPanel textfieldCardPanel;
    private JScrollPane treeScrollPane;
    private JScrollPane listScrollPane;

    private NarrowerTask currentNarrowerTask;
    private TaskQueue narrowerTaskQueue;

    public SearchableBeanPathSelector(BeanCollectionTableModel beanCollectionTableModel, FilteredTreeModel.Filter addPropertyFilter, FilteredTreeModel.Filter addChildrenFilter, BeanPathSelector.SelectionModel selectionModel) {
        setLayout(new BorderLayout());

        dummySearchBox = new JTextField("Quick Search");
        dummySearchBox.setForeground(Color.lightGray);
        dummySearchBox.setMaximumSize(new Dimension(dummySearchBox.getMaximumSize().width, dummySearchBox.getPreferredSize().height));

        searchBox = new SearchField();
        searchBox.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                doNarrow();
            }

            public void removeUpdate(DocumentEvent e) {
                doNarrow();
            }

            public void changedUpdate(DocumentEvent e) {
            }
        });
        searchBox.setMaximumSize(new Dimension(searchBox.getMaximumSize().width, searchBox.getPreferredSize().height));

        JButton clearButton = new JButton(new ClearAction());
        clearButton.setBorder(new EmptyBorder(0, 0, 0, 0));
        clearButton.setFocusable(false);

        textfieldCardPanel = new CardPanel();
        textfieldCardPanel.addComponent(dummySearchBox);
        textfieldCardPanel.addComponent(searchBox);
        textfieldCardPanel.setSelectedComponent(dummySearchBox);
        dummySearchBox.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                textfieldCardPanel.setSelectedComponent(searchBox);
                searchBox.requestFocusInWindow();
            }
        });
        searchBox.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                if (!e.isTemporary() && searchBox.getText().length() == 0) {
                    textfieldCardPanel.setSelectedComponent(dummySearchBox);
                }
            }
        });

        this.beanPathSelector = new BeanPathSelector(beanCollectionTableModel, addPropertyFilter, addChildrenFilter, selectionModel) {
            protected void processKeyEvent(KeyEvent e) {
                if (e.getID() == KeyEvent.KEY_PRESSED && isValidPropertyChar(e.getKeyChar())) {
                    searchBox.replaceSelection("" + e.getKeyChar());
                    textfieldCardPanel.setSelectedComponent(searchBox);
                    searchBox.requestFocusInWindow();
                } else {
                    super.processKeyEvent(e);
                }
            }
        };

        treeOrList = new CardPanel();
        searchResultsModel = new SearchResultsTreeModel();
        searchResults = new SearchResults();
        beanCollectionTableModel.addTableModelListener(new TableModelListener() {
            public void tableChanged(TableModelEvent e) {
                if (e.getFirstRow() == TableModelEvent.HEADER_ROW && e.getLastRow() == TableModelEvent.HEADER_ROW) {
                    searchResults.repaint();
                }
            }
        });

        searchResults.setCellRenderer(new SearchResultsTreeCellRenderer(selectionModel, searchResultsModel));
        searchResults.addMouseListener(new BeanPathSelector.BeanPropertyTreeMouseHandler(selectionModel));

        treeScrollPane = new JScrollPane(beanPathSelector);
        listScrollPane = new JScrollPane(searchResults);

        treeOrList.addComponent(treeScrollPane);
        treeOrList.addComponent(listScrollPane);
        treeOrList.setSelectedComponent(treeScrollPane);

//        JScrollPane scrollpane = new JScrollPane(treeOrList);
//        scrollpane.getViewport().setBackground(beanPathSelector.getBackground());

        Box textFieldAndClearButton = new Box(BoxLayout.X_AXIS);
        textFieldAndClearButton.add(textfieldCardPanel);
        textFieldAndClearButton.add(clearButton);

        add(textFieldAndClearButton, BorderLayout.NORTH);
        add(treeOrList, BorderLayout.CENTER);
    }

    public void updateUI() {
        if (searchResults != null) searchResults.setCellRenderer(new SearchResultsTreeCellRenderer(beanPathSelector.getBeanPathSelectionModel(), searchResultsModel));
    }

    private void doNarrow() {
        if (narrowerTaskQueue == null) {
            narrowerTaskQueue = new TaskQueue("BeanPathSelector.Narrower");
            narrowerTaskQueue.start();
        }
        if (currentNarrowerTask != null) currentNarrowerTask.cancel();
        currentNarrowerTask = new NarrowerTask(searchBox.getText().toLowerCase());
        narrowerTaskQueue.addTask(currentNarrowerTask);
    }

    /**
     * Narrows the field list in a background thread.
     */
    private class NarrowerTask extends Task {
        private String searchText;
        boolean cancelSearch = false;
        private static final int TYPING_DELAY = 50;

        public NarrowerTask(String searchText) {
            super("NarrowerTask " + searchText);
            this.searchText = searchText;
        }

        synchronized void cancel() {
            cancelSearch = true;  // cancel current search
        }

        public void run() {
            synchronized (this) {
                if (cancelSearch) return;
            }
            if (searchText.length() == 0) { // just switch to tree view
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        treeOrList.setSelectedComponent(treeScrollPane);
                    }
                });
                return;
            }
            final ArrayList filtered = new ArrayList();
            for (Iterator iterator = getFlattenedTree().iterator(); iterator.hasNext();) {
                synchronized (this) {
                    if (cancelSearch) return;
                }
                BeanPropertyTreeNode property = (BeanPropertyTreeNode) iterator.next();
                if (quickSearchAcceptSubstring) {
                    if (property.getDisplayName().toLowerCase().indexOf(searchText) != -1) {
                        filtered.add(property);
                    }
                } else {
                    if (property.getDisplayName().toLowerCase().startsWith(searchText)) {
                        filtered.add(property);
                    }
                }
            }
            try {
                /**
                 * Slight delay to give the user time to type another character - GUI update is time costly.
                 */
                Thread.sleep(TYPING_DELAY);
            } catch (InterruptedException e) {
                // ignore
            }
            EventQueue.invokeLater(new Runnable() {
                public void run() {
                    synchronized (NarrowerTask.this) {
                        if (cancelSearch) return;
                    }
                    searchResultsModel.setRootChildren(filtered);
                    treeOrList.setSelectedComponent(listScrollPane);
                    searchResults.clearSelection();
                    searchBox.requestFocusInWindow();
                }
            });
        }

        public boolean equals(Object obj) {
            return (obj instanceof NarrowerTask);
        }

        public int hashCode() {
            return 100; // all objects use the same hash code so they replace each other in the task queue
        }
    }

    /**
     * Get the flattened tree lazily, as it can end up inflating many nodes.
     * Save on memory and cpu.
     */
    private ArrayList getFlattenedTree() {
        if (flattenedTree == null) {
            BeanPropertyTreeNode root = (BeanPropertyTreeNode) beanPathSelector.getModel().getRoot();
            flattenedTree = flattenTree(root);
        }
        return flattenedTree;
    }

    /**
     * breadth first walks the beanPathSelector from the given node (non-inclusive), adding nodes to the given searchResults
     *
     * @param propertyNode
     */
    private ArrayList flattenTree(BeanPropertyTreeNode propertyNode) {
        ArrayList list = new ArrayList();
        int nextListItem = -1;
        while (nextListItem < list.size()) {
            if (nextListItem > -1) propertyNode = (BeanPropertyTreeNode) list.get(nextListItem);

            if (propertyNode.getLevel() >= MAX_SEARCH_DEPTH) break;
            int count = beanPathSelector.getModel().getChildCount(propertyNode);
            for (int i = 0; i < count; i++) {
                Object child = beanPathSelector.getModel().getChild(propertyNode, i);
                list.add(child);
            }
            nextListItem++;
        }
        return list;
    }


    public void dispose() {
        beanPathSelector.dispose();
    }

    public void reset() {
        beanPathSelector.reset();
    }

    public void setSelected(boolean add) {
        beanPathSelector.setSelected(add);
    }

    private static boolean isNavigationKey(KeyEvent e) {
        int keyCode = e.getKeyCode();
        return navigationKeyCodeSet.contains(new Integer(keyCode));
    }

    public static boolean isQuickSearchAcceptSubstring() {
        return quickSearchAcceptSubstring;
    }

    public static void setQuickSearchAcceptSubstring(boolean quickSearchAcceptSubstring) {
        SearchableBeanPathSelector.quickSearchAcceptSubstring = quickSearchAcceptSubstring;
    }

    private boolean isValidPropertyChar(char c) {
        return Character.isLetterOrDigit(c)
                || Character.isSpaceChar(c)
                || c == '_'
                || c == '('
                || c == ')';
    }

    private static class ScrollableCardPanel extends CardPanel implements Scrollable {
        public Dimension getPreferredSize() {
            return getSelectedComponent().getPreferredSize();
        }

        public Dimension getMinimumSize() {
            return getSelectedComponent().getMinimumSize();
        }

        public Dimension getMaximumSize() {
            return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
        }

        public Dimension getPreferredScrollableViewportSize() {
            return ((Scrollable) getSelectedComponent()).getPreferredScrollableViewportSize();
        }

        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return ((Scrollable) getSelectedComponent()).getScrollableBlockIncrement(visibleRect, orientation, direction);
        }

        public boolean getScrollableTracksViewportHeight() {
            return ((Scrollable) getSelectedComponent()).getScrollableTracksViewportHeight();
        }

        public boolean getScrollableTracksViewportWidth() {
            return ((Scrollable) getSelectedComponent()).getScrollableTracksViewportWidth();
        }

        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return ((Scrollable) getSelectedComponent()).getScrollableUnitIncrement(visibleRect, orientation, direction);
        }
    }

    private class SearchResults extends JTree {
        private PropertyToolTipFactory propertyToolTipFactory = new BeanpathSelectorPropertyToolTipFactory();

        public SearchResults() {
            super(searchResultsModel);
            setRootVisible(false);
            setShowsRootHandles(true);
            putClientProperty("JTree.lineStyle", "None");
            ToolTipManager.sharedInstance().registerComponent(this);
        }

        protected void processKeyEvent(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER && e.getID() == KeyEvent.KEY_PRESSED) {
                TreePath selectionPath = getSelectionPath();
                if (selectionPath != null) {
                    BeanPropertyTreeNode property = (BeanPropertyTreeNode) selectionPath.getLastPathComponent();
                    if (!property.isPropertyGroup() && PropertyModel.getInstance(property.getAttribute().getType()).isSelectable()) {
                        beanPathSelector.getBeanPathSelectionModel().locatorSelected(property.getBeanPath());
                        return;
                    }

                    if (isExpanded(selectionPath)) {
                        collapsePath(selectionPath);
                    } else {
                        expandPath(selectionPath);
                    }
                }
            } else {
                super.processKeyEvent(e);
            }
        }

        public String getToolTipText(MouseEvent event) {
            return propertyToolTipFactory.getToolTipText(event);
        }

        public JToolTip createToolTip() {
            return propertyToolTipFactory.createToolTip();
        }

        private class BeanpathSelectorPropertyToolTipFactory extends PropertyToolTipFactory {
            public String getToolTipText(MouseEvent event) {
                TreePath path = getPathForLocation(event.getX(), event.getY());
                if (path != null && path.getPathCount() > 1) {
                    BeanPropertyTreeNode property = ((BeanPropertyTreeNode) path.getLastPathComponent());
                    BeanPropertyTreeNode rootProperty = property.getRootProperty();
                    return getToolTipText(rootProperty.getAttribute().getType(), property.getBeanPath());
                }
                return null;
            }
        }
    }

    private class SearchField extends JTextField {
        protected void processKeyEvent(KeyEvent e) {
            if (e.getID() == KeyEvent.KEY_PRESSED && isNavigationKey(e)) {
                Component selectedComponent = treeOrList.getSelectedComponent();
                if (selectedComponent == listScrollPane) {
                    searchResults.processKeyEvent(e);
                } else if (selectedComponent == treeScrollPane) {
                    beanPathSelector.processKeyEvent(e);
                }
            } else {
                super.processKeyEvent(e);
            }
        }
    }


    private class SearchResultsTreeModel implements TreeModel {
        private IndexedSet root = new IndexedSet();
        private ArrayList listeners = new ArrayList();

        public void setRootChildren(Collection children) {
            root.clear();
            root.addAll(children);
            fireModelChanged();
        }

        public Object getChild(Object parent, int index) {
            if (parent == root) return root.get(index);
            return beanPathSelector.getModel().getChild(parent, index);
        }

        public int getChildCount(Object parent) {
            if (parent == root) return root.size();
            return beanPathSelector.getModel().getChildCount(parent);
        }

        public int getIndexOfChild(Object parent, Object child) {
            if (parent == root) return root.indexOf(child);
            return beanPathSelector.getModel().getIndexOfChild(parent, child);
        }

        public Object getRoot() {
            return root;
        }

        public boolean isLeaf(Object node) {
            if (node == root) return root.size() == 0;
            return beanPathSelector.getModel().isLeaf(node);
        }

        public void addTreeModelListener(TreeModelListener l) {
            listeners.add(l);
        }

        public void removeTreeModelListener(TreeModelListener l) {
            listeners.remove(l);
        }

        private void fireModelChanged() {
            TreeModelEvent e = new TreeModelEvent(this, new Object[]{root});
            for (Iterator iterator = listeners.iterator(); iterator.hasNext();) {
                TreeModelListener l = (TreeModelListener) iterator.next();
                l.treeStructureChanged(e);
            }
        }

        public void valueForPathChanged(TreePath path, Object newValue) {
        }

        public boolean isTopLevelChild(Object value) {
            return root.contains(value);
        }
    }

    private static class SearchResultsTreeCellRenderer extends BeanPathSelector.PropertyTreeCellRenderer {
        private SearchResultsTreeModel model;

        public SearchResultsTreeCellRenderer(BeanPathSelector.SelectionModel beanPathSelectionModel, SearchResultsTreeModel model) {
            super(beanPathSelectionModel);
            this.model = model;
        }

        protected String getStringForValue(Object value) {
            BeanPropertyTreeNode property = (BeanPropertyTreeNode) value;

            if (model.isTopLevelChild(value)) {
                StringBuffer itemString = new StringBuffer();
                BeanPropertyTreeNode[] pathFromRoot = property.getPropertyPathFromRoot();

                for (int i = 1; i < pathFromRoot.length; i++) {
                    BeanPropertyTreeNode parentProperty = pathFromRoot[i];
                    itemString.append(parentProperty.getDisplayName());
                    if (i < pathFromRoot.length - 1) itemString.append(" - ");
                }
                return itemString.toString();
            } else {
                return property.getDisplayName();
            }
        }
    }

    private class ClearAction extends AuditedAbstractAction {
        public ClearAction() {
            super("", null, "Clear searchable box");
            putValue(Action.SMALL_ICON, CLEAR_ICON);
        }

        public void auditedActionPerformed(ActionEvent e) {
            searchBox.setText("");
            textfieldCardPanel.setSelectedComponent(dummySearchBox);
        }
    }
}
