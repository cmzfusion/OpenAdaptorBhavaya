package org.bhavaya.ui.freechart.builder;

import org.jfree.chart.JFreeChart;
import org.bhavaya.ui.table.KeyedColumnTableModel;
import org.bhavaya.ui.table.AnalyticsTableModel;
import org.bhavaya.ui.freechart.ChartViewConfiguration;
import org.bhavaya.collection.BeanCollection;

/**
 * Created by IntelliJ IDEA.
 * User: Nick Ebbutt
 * Date: 25-Feb-2008
 * Time: 14:18:04
 *
 * Build a chart from a BeanCollection in two stages -
 * first a table model which performs any necessary grouping/sorting
 * then the JFreechart instance
 */
public interface ChartBuilder {

    AnalyticsTableModel buildTableModel( ChartViewConfiguration chartViewConfiguration, BeanCollection beanCollection);

    JFreeChart buildChart( ChartViewConfiguration chartViewConfiguration, KeyedColumnTableModel keyedTableModel);
}
