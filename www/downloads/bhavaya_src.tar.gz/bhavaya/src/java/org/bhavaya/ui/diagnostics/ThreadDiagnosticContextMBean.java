package org.bhavaya.ui.diagnostics;

/**
 * Created by IntelliJ IDEA.
 * User: brendon
 * Date: Sep 20, 2006
 * Time: 4:32:33 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ThreadDiagnosticContextMBean {
    public void performThreadDump();
}
