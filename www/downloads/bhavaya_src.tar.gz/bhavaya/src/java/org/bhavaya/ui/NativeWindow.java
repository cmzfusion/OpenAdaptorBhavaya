/* Copyright (C) 2000-2003 The Software Conservancy as Trustee.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Nothing in this notice shall be deemed to grant any rights to trademarks,
 * copyrights, patents, trade secrets or any other intellectual property of the
 * licensor or any contributor except as expressly stated herein. No patent
 * license is granted separate from the Software, for code that you delete from
 * the Software, or for combinations of the Software with other software or
 * hardware.
 */

package org.bhavaya.ui;

import org.bhavaya.util.Log;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.WeakHashMap;

/**
 * Description
 *
 * @author Brendon McLean
 * @version $Revision: 1.4 $
 */
public class NativeWindow {
    private static final Log log = Log.getCategory(NativeWindow.class);

    private static boolean libraryLoaded = false;
    private static int javaMinorVersion;
    private static WeakHashMap frameToNativeWindowMap = new WeakHashMap();

    /** Flash both the window caption and taskbar button. This is equivalent to setting the FLASHW_CAPTION | FLASHW_TRAY flags. */
    public static final int FLASHW_ALL = 0x00000003;
    /** Flash the window caption */
    public static final int FLASHW_CAPTION = 0x00000001;
    /** Stop flashing. The system restores the window to its original state. */
    public static final int FLASHW_STOP = 0;
    /** Flash continuously, until the FLASHW_STOP flag is set. */
    public static final int FLASHW_TIMER = 0x00000004;
    /** Flash continuously until the window comes to the foreground. */
    public static final int FLASHW_TIMERNOFG = 0x0000000C;
    /** Flash the taskbar button. */
    public static final int FLASHW_TRAY = 0x00000002;

    static {
        try {
            System.loadLibrary("GuiGadgets");
            libraryLoaded = true;
            javaMinorVersion = Integer.parseInt(System.getProperty("java.version").substring(2, 3));
        } catch (Throwable t) {
            log.warn("Could not load GuiGadgets library.");
        }
    }

    public static boolean isLibraryLoaded() {
        return libraryLoaded;
    }

    public static NativeWindow getInstance(Frame frame) {
        NativeWindow nativeWindow = (NativeWindow) frameToNativeWindowMap.get(frame);
        if (nativeWindow == null) {
            nativeWindow = new NativeWindow(frame);
            frameToNativeWindowMap.put(frame, nativeWindow);
        }
        return nativeWindow;
    }

    public static boolean isAlwaysOnTop(Frame frame) {
        // this will never create a new instance of NativeWindow, and can be called from any thread
        return libraryLoaded && frameToNativeWindowMap.containsKey(frame) && ((NativeWindow) frameToNativeWindowMap.get(frame)).isAlwaysOnTop();
    }

    private int win32Pointer = 0;
    private boolean alwaysOnTop;

    private NativeWindow(final Frame frame) {
        if (frame.isShowing()) {
            win32Pointer = getWin32Pointer(frame);
        } else {
            frame.addWindowListener(new WindowAdapter() {
                public void windowOpened(WindowEvent e) {
                    win32Pointer = getWin32Pointer(frame);
                }

                public void windowClosing(WindowEvent e) {
                    frame.removeWindowListener(this);
                }
            });
        }
    }

    public void setAlwaysOnTop(boolean alwaysOnTop) {
        assert EventQueue.isDispatchThread() : "Should only be called on Event Dispatch thread";
        setAlwaysOnTopWin32(win32Pointer, alwaysOnTop);
        this.alwaysOnTop = alwaysOnTop;
    }

    public boolean isAlwaysOnTop() {
        return alwaysOnTop;
    }

    /**
     * Flashes taskbar icon and makes sure the taskbar is visible
     */
    public void flashTaskbarIcon() {
        assert EventQueue.isDispatchThread() : "Should only be called on Event Dispatch thread";
        flashWin32(win32Pointer, 3, FLASHW_TRAY, 0);
    }

    private int getWin32Pointer(Frame frame) {
        assert frame.isShowing() : "Frame must be showing before setAlwaysOnTop can be called";
        assert EventQueue.isDispatchThread() : "Should only be called on Event Dispatch thread";
        int hwnd = 0;
        if (javaMinorVersion >= 3) hwnd = getWin32HwndByFrame(frame, javaMinorVersion);
        if (hwnd == 0) {
            log.warn("Could not dynamically link to jawt.dll, attempting to find Win32 handle by frame name");
            hwnd = getWin32HwndByFrameTitle(frame.getTitle());
            if (hwnd == 0) throw new RuntimeException("Could not locate Win32 HWND handle");
        }
        return hwnd;
    }

    private native void setAlwaysOnTopWin32(int hwnd, boolean alwaysOnTop);

    private native void flashWin32(int hwnd, int count, int flags, int flashRate);

    private native int getWin32HwndByFrame(Frame frame, int javaMinorVersion);

    private native int getWin32HwndByFrameTitle(String frame);

    public static void main(String[] args) {
        final JFrame frame = new JFrame("Wagga");
        JPanel panel = new JPanel();
        panel.add(new JToggleButton(new AbstractAction("OnTop") {
            public void actionPerformed(ActionEvent e) {
                JToggleButton toggleButton = (JToggleButton) e.getSource();
                getInstance(frame).setAlwaysOnTop(toggleButton.isSelected());
            }
        }));
        frame.getContentPane().add(panel);
        frame.pack();
        frame.show();
    }
}
