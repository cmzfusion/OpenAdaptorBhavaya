package org.bhavayademo.beans;

/**
 * @author Parwinder Sekhon
 * @version $Revision: 1.1 $
 */
public abstract class VersionStatus extends org.bhavaya.util.LookupValue   {

}
