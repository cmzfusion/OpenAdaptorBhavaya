
/**
 * Date: 19-Apr-2004
 * Time: 10:45:37
 */
public interface ShutDownOperation {
    public abstract void shutDown();
}
