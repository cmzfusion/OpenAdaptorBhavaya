
import org.bhavaya.ui.NativeWindow;

import javax.swing.*;

/**
 * Date: 08-Mar-2004
 * Time: 14:27:31
 */
public class OnTopDemo {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Always on top demo");
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Window is always on top");

        final NativeWindow window = NativeWindow.getInstance(frame);

        panel.add(label);
        frame.setContentPane(panel);
        frame.setSize(200,55);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        SwingUtilities.invokeLater(new Runnable(){
                   public void run(){
                        window.setAlwaysOnTop(true);
                   }
               });

    }
}
