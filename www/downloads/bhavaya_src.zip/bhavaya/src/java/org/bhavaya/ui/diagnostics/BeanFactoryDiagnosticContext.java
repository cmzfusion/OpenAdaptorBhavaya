package org.bhavaya.ui.diagnostics;

import org.bhavaya.ui.MenuGroup;
import org.bhavaya.ui.AuditedAbstractAction;
import org.bhavaya.util.Log;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

/**
 * Provides reports on BeanFactory listener counts.  This helps check for bean-related memory leaks.
 *
 * @author Brendon McLean
 * @version $Revision: 1.5 $
 */
public class BeanFactoryDiagnosticContext extends DiagnosticContext {
    private static final Log log = Log.getCategory(BeanFactoryDiagnosticContext.class);

    public BeanFactoryDiagnosticContext() {
        super("Bean Factory Statistics", null);
    }

    public Component createComponent() {
        return null;
    }

    public String createHTMLDescription() {
        StringBuffer buffer = new StringBuffer();
        DiagnosticUtilities.contextHeader(buffer, "Bean Factories");
        DiagnosticUtilities.tableHeader(buffer);

        DiagnosticUtilities.tableHeaderRow(buffer, new Object[]{"Type", "Bean Count", "Listener Count"});

        BeanFactoryStatistics[] beanFactoriesStatistics = getBeanFactoriesStatistics();
        for (int i = 0; i < beanFactoriesStatistics.length; i++) {
            BeanFactoryStatistics beanFactoryStatistics = beanFactoriesStatistics[i];
            if (beanFactoryStatistics.getBeanCount() > 0 || beanFactoryStatistics.getListenerCount() > 0) {
                DiagnosticUtilities.tableRow(buffer, new Object[]{beanFactoryStatistics.getType(),
                                                                  "" + beanFactoryStatistics.getBeanCount(),
                                                                  "" + beanFactoryStatistics.getListenerCount()});
            }
        }
        DiagnosticUtilities.tableFooter(buffer);
        return buffer.toString();
    }

    public MenuGroup[] createMenuGroups() {
        MenuGroup settingsMenuGroup = new MenuGroup("Options", KeyEvent.VK_O);

        settingsMenuGroup.addElement(new MenuGroup.MenuItemElement(new JMenuItem(new GarbageCollectionAction())));
        return new MenuGroup[]{settingsMenuGroup};
    }

    public static BeanFactoryStatistics[] getBeanFactoriesStatistics() {
        int totalSize = 0;
        int totalListeners = 0;
        org.bhavaya.beans.BeanFactory[] beanFactories = org.bhavaya.beans.BeanFactory.getInstances();
        BeanFactoryStatistics[] beanFactoriesStatistics = new BeanFactoryStatistics[beanFactories.length + 1];
        for (int i = 0; i < beanFactories.length; i++) {
            org.bhavaya.beans.BeanFactory beanFactory = beanFactories[i];
            String type = beanFactory.getType().getName();
            boolean classLoaded = beanFactory.isClassLoaded();
            int size = classLoaded ? beanFactory.size() : -1;
            int listeners = classLoaded ? beanFactory.getMapListenerCount() : -1;

            beanFactoriesStatistics[i] = new BeanFactoryStatistics(type, size, listeners);

            totalSize += size;
            totalListeners += listeners;
        }
        beanFactoriesStatistics[beanFactoriesStatistics.length - 1] = new BeanFactoryStatistics("Total", totalSize, totalListeners);
        return beanFactoriesStatistics;
    }

    public static class BeanFactoryStatistics {
        private String type;
        private int beanCount;
        private int listenerCount;

        public BeanFactoryStatistics(String type, int beanCount, int listenerCount) {
            this.type = type;
            this.beanCount = beanCount;
            this.listenerCount = listenerCount;
        }

        public String getType() {
            return type;
        }

        public int getBeanCount() {
            return beanCount;
        }

        public int getListenerCount() {
            return listenerCount;
        }

        public String toString() {
            return "Type: " + type + ", beanCount: " + beanCount + ", listenerCount: " + listenerCount;
        }
    }

    private class GarbageCollectionAction extends AuditedAbstractAction {
        public GarbageCollectionAction() {
            putValue(Action.NAME, "Garbage Collect");
        }

        public void auditedActionPerformed(ActionEvent e) {
            // logging stats has an important side-effect, it touches all beanFactories,
            // which triggers any weak referenced beans to be removed (it is a lazy operation)
            logBeanFactoryStatistics();
            System.gc();
        }

        private void logBeanFactoryStatistics() {
            StringBuffer buffer = new StringBuffer("");
            buffer.append("BeanFactory statistics\n");
            buffer.append("Type\tBean Count\tListener Count\n");

            BeanFactoryStatistics[] beanFactoriesStatistics = getBeanFactoriesStatistics();

            for (int i = 0; i < beanFactoriesStatistics.length; i++) {
                BeanFactoryStatistics beanFactoryStatistics = beanFactoriesStatistics[i];
                if (beanFactoryStatistics.getBeanCount() > 0 || beanFactoryStatistics.getListenerCount() > 0) {
                    buffer.append(beanFactoryStatistics.getType() + "\t" + beanFactoryStatistics.getBeanCount() + "\t"
                            + beanFactoryStatistics.getListenerCount() + "\n");
                }

            }
            log.info(buffer.toString());
        }
    }

    public Attachment[] createAttachments() {
        return new Attachment[0];
    }
}
