/* Copyright (C) 2000-2003 The Software Conservancy as Trustee.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Nothing in this notice shall be deemed to grant any rights to trademarks,
 * copyrights, patents, trade secrets or any other intellectual property of the
 * licensor or any contributor except as expressly stated herein. No patent
 * license is granted separate from the Software, for code that you delete from
 * the Software, or for combinations of the Software with other software or
 * hardware.
 */

package org.bhavaya.coms;

import org.bhavaya.util.Log;
import org.openadaptor.adaptor.IbafException;
import org.openadaptor.adaptor.RunAdaptor;

import java.util.Properties;

/**
 * Description.
 *
 * @author Parwinder Sekhon
 * @version $Revision: 1.2 $
 */
public class OpenAdapter {
    private static final Log log = Log.getCategory(OpenAdapter.class);

    protected RunAdaptor adaptor;
    private String adaptorName;
    private Properties properties;

    protected OpenAdapter(String adapterName, Properties properties) {
        this.adaptorName = adapterName;
        this.properties = properties;
    }

    public void start() throws NotificationException {
        // get Adapter
        try {
            adaptor = new RunAdaptor(adaptorName, properties);
            adaptor.getController().setExitAllowed(false);
        } catch (IbafException ibe) {
            log.error("Failed to create adaptor, " + ibe.toString());
            throw new NotificationException(ibe);
        }
    }

    public synchronized void close() {
        try {
            if (adaptor != null) {
                adaptor.getController().terminate();
                adaptor = null;
            }
        } catch (Exception e) {
            if (log.isDebug()) log.debug(e.toString());
        }
    }

    protected static class FailoverRunAdaptor implements Runnable {
        private int reconnectionPeriod;
        private RunAdaptor runAdaptor;
        private OpenAdapter openAdapter;
        private int reconnectionAttempt;

        public FailoverRunAdaptor(RunAdaptor runAdaptor, OpenAdapter openAdapter, int reconnectionPeriod) {
            this.runAdaptor = runAdaptor;
            this.openAdapter = openAdapter;
            this.reconnectionPeriod = reconnectionPeriod;
        }

        public void run() {
            try {
                runAdaptor.run();
            } catch (Exception e) {
                log.error(e);
            }
            log.error("Failed will attempt reconnection in " + reconnectionPeriod + " millis");

            try {
                openAdapter.close();
            } catch (Exception e) {
                log.error(e);
            }

            while (true) {
                try {
                    Thread.sleep(reconnectionPeriod);
                } catch (InterruptedException e) {
                    log.error(e);
                }

                try {
                    reconnectionAttempt++;
                    log.error("Attemping reconnection attempt " + reconnectionAttempt);
                    openAdapter.start();
                    break;
                } catch (Exception e) {
                    log.error(e);
                }
            }
        }
    }
}
