package org.bhavaya.ui.diagnostics;

import EDU.oswego.cs.dl.util.concurrent.Mutex;
import com.sun.jdmk.comm.HtmlAdaptorServer;
import org.bhavaya.util.*;
import org.bhavaya.ui.ArrayListModel;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.Priority;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: brendon
 * Date: Nov 14, 2005
 * Time: 4:03:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class HeadlessApplicationDiagnostics {
    private static final Log log = Log.getCategory(ApplicationDiagnostics.class);

    public static final int MAX_LOG_MESSAGES = 5000;
    private static final int MAX_HEAD_LOG_MESSAGES_TO_KEEP = 50; // must be smaller than MAX_LOG_MESSAGES

    protected static Mutex instanceMutext = new Mutex();
    protected static HeadlessApplicationDiagnostics instance;

    protected ArrayList<DiagnosticContext> diagnosticContexts = new ArrayList<DiagnosticContext>();

    private MBeanServer mBeanServer;
    private HashSet<StackTraceElement> sendDiagnosticMessageCallerStackFrame = new HashSet<StackTraceElement>();
    private boolean logBeanToScreenDelays;
    private ArrayList<String> debugLogPackageList = new ArrayList<String>();

    protected ArrayListModel allLogStatements = new ArrayListModel(new LinkedList());
    protected ArrayListModel warnLogStatements = new ArrayListModel(new LinkedList());
    protected ArrayListModel errorLogStatements = new ArrayListModel(new LinkedList());
    protected java.util.List<ApplicationDiagnostics.LoggingEventBean> exceptionLogStatements = new LinkedList<LoggingEventBean>();

    private int mBeanServerHtmlAdaptorPort;

    public static HeadlessApplicationDiagnostics getHeadlessInstance() {
        ThreadUtilities.quietAquire(instanceMutext);
        if (instance == null) instance = new HeadlessApplicationDiagnostics();
        instanceMutext.release();
        return instance;
    }

    protected HeadlessApplicationDiagnostics() {
        Log.getRoot().addListener(new LogListener(isHeadless()));
    }

    protected boolean isHeadless() {
        return true;
    }

    public void addDiagnosticContext(DiagnosticContext diagnosticContext) {
        log.info("Registering diagnostic context: " + diagnosticContext.getName());
        diagnosticContexts.add(diagnosticContext);
        registerMBeanForDiagnosticContext(diagnosticContext);
    }

    public void productionAssert(boolean condition, String message) {
        if (!condition) {
            assert false : message;
            //this line will only get run if the vm is not running with assertions enabled (i.e. production clients)
            sendDiagnosticReportOnlyOnce(message);
        }
    }

    public ArrayListModel getAllLogStatements() {
        return allLogStatements;
    }

    public ArrayListModel getWarnLogStatements() {
        return warnLogStatements;
    }

    public ArrayListModel getErrorLogStatements() {
        return errorLogStatements;
    }

    public List getExceptionLogStatements() {
        return exceptionLogStatements;
    }

    public void addApplicationDebugLogPackage(String debugLogPackage) {
        debugLogPackageList.add(debugLogPackage);
    }

    public String createDiagnosticReport(String userComments, boolean attachments) throws UnsupportedEncodingException {
        StringBuffer reportBuffer = new StringBuffer("<html>"
                + "<font face=arial size=4><center><b>Diagnostic report for " + ApplicationInfo.getInstance().getName() + "</b></center></font><br><br>");

        reportBuffer.append(createUserCommentsSummary(userComments)).append("<br><br><br>");
        for (DiagnosticContext diagnosticContext : diagnosticContexts) {
            String htmlDescription = null;

            try {
                htmlDescription = diagnosticContext.createHTMLDescription();
            } catch (Throwable e) {
                log.error("DiagnosticContext generated error: " + diagnosticContext.getName(), e);
            }

            if (htmlDescription != null) reportBuffer.append(htmlDescription).append("<br><br>");
        }

        if (attachments) reportBuffer.append("<font face=Arial size=1><i>Files attached in details.zip</i></font>");
        reportBuffer.append("</html>");

        return reportBuffer.toString();
    }

    private String createUserCommentsSummary(String userComments) {
        return "<b><font face=arial>User comments</font></b><br>"
                + (userComments == null || userComments.length() == 0 ? "None" : userComments);
    }

    public void sendDiagnosticReportOnlyOnce(String comments) {
        StackTraceElement[] stackTrace = new Throwable().getStackTrace();
        if (!sendDiagnosticMessageCallerStackFrame.contains(stackTrace[1])) {
            StringBuffer message = new StringBuffer("<html>Automated report from:<br>");
            for (int i = 1; i < stackTrace.length; i++) {
                message.append("     ").append(stackTrace[i]).append("<br>\n");
            }
            message.append("Message:<br>\n");
            message.append(comments).append("</html>");
            sendDiagnosticReport(message.toString());
            sendDiagnosticMessageCallerStackFrame.add(stackTrace[1]);
        }
    }

    public void sendDiagnosticReport(String comments) {
        sendDiagnosticReportOnSmtp(comments, ApplicationProperties.getApplicationProperties().getMandatoryProperty("emailService.to"));
    }

    public void sendDiagnosticReport(String comments, String emailAddress) {
        sendDiagnosticReportOnSmtp(comments, addDomainToEmail(emailAddress));
    }

    public void sendDiagnosticReportOnSmtp(String comments, String emailAddress) {
        try {
            String subject = createDiagnosticSubject("Diagnostic report");
            Message mailMessage = EmailUtilities.getDefaultMimeMessage(new String[] {emailAddress}, subject);
            MimeBodyPart summaryBodyPart = new MimeBodyPart();

            byte[] attachmentData = zipAttachment();
            boolean attachments = (attachmentData != null);


            summaryBodyPart.setContent(MimeUtility.encodeText(Utilities.escapeHtmlCharacters(createDiagnosticReport(comments, attachments))), "text/html");
            summaryBodyPart.setHeader("Content-Type", "text/html; charset=iso-8859-1");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(summaryBodyPart);

            if (attachments) {
                MimeBodyPart logAttachment = new MimeBodyPart();
                logAttachment.setDataHandler(new DataHandler(new EmailUtilities.ByteArrayDataSource(attachmentData, "application/zip")));
                logAttachment.setFileName("details.zip");
                multipart.addBodyPart(logAttachment);
            }

            mailMessage.setContent(multipart);
            EmailUtilities.sendMessage(mailMessage);
            log.info("Sent diagnostic report to: " + emailAddress);
        } catch (Throwable ex) {
            log.error("Unable to send exception report", ex);
        }
    }

    public void sendQuickDiagnosticMessage(String type, String message, boolean html) {
        EmailUtilities.sendQuickMessage(createDiagnosticSubject(type), message, html);
    }

    private String createDiagnosticSubject(String type) {
        return ApplicationInfo.getInstance().getName() + ": " + type
                + ": environment: " + ApplicationInfo.getInstance().getEnvironmentName()
                + ", username: " + ApplicationInfo.getInstance().getUsername();
    }

    public void sendFile(String fileName) {
        try {
            String username = ApplicationInfo.getInstance().getUsername();
            String subject = ApplicationInfo.getInstance().getName() + ": Files: environment: "
                    + ApplicationInfo.getInstance().getEnvironmentName() + ", username: " + username;
            Message mailMessage = EmailUtilities.getDefaultMimeMessage(subject);

            MimeBodyPart logAttachment = null;
            byte[] data = zipFile(fileName);
            if (data != null && data.length > 0) {
                logAttachment = new MimeBodyPart();
                logAttachment.setDataHandler(new DataHandler(new EmailUtilities.ByteArrayDataSource(data, "application/zip")));
                File f = new File(fileName);
                logAttachment.setFileName(f.getName() + ".zip");
            }

            MimeBodyPart summaryBodyPart = new MimeBodyPart();
            summaryBodyPart.setContent(createSendFilesReport("", logAttachment != null), "text/html");
            summaryBodyPart.setHeader("Content-Type", "text/html; charset=iso-8859-1");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(summaryBodyPart);
            if (logAttachment != null) multipart.addBodyPart(logAttachment);

            mailMessage.setContent(multipart);
            EmailUtilities.sendMessage(mailMessage);
            log.info("Sent file " + fileName + " to: " + ApplicationProperties.getApplicationProperties().getMandatoryProperty("emailService.to"));
        } catch (Throwable t) {
            log.error("Unable to send file " + fileName, t);
        }
    }

    protected String createSendLogFilesReport(String userComments, boolean hasAttachments) {
        StringBuffer buffer = new StringBuffer("<html>"
                + "<font face=arial><b>Log files for " + ApplicationInfo.getInstance().getName() + "</b></font><br><hr size=1><br>");
        buffer.append(createUserCommentsSummary(userComments)).append("<br><br><br>");
        if (!hasAttachments) {
            buffer.append("No log files found.");
        } else {
            buffer.append("<font face=Arial size=1><i>Log files attached.</i></font>");
        }
        buffer.append("</html>");
        return buffer.toString();
    }

    protected String createSendFilesReport(String userComments, boolean hasAttachments) {
        StringBuffer buffer = new StringBuffer("<html>"
                + "<font face=arial><b>Files for " + ApplicationInfo.getInstance().getName() + "</b></font><br><hr size=1><br>");
        buffer.append(createUserCommentsSummary(userComments)).append("<br><br><br>");
        if (!hasAttachments) {
            buffer.append("No files found.");
        } else {
            buffer.append("<font face=Arial size=1><i>Files attached.</i></font>");
        }
        buffer.append("</html>");
        return buffer.toString();
    }

    private byte[] zipAttachment() throws IOException {
        LinkedList<DiagnosticContext.Attachment> attachmentsList = new LinkedList<DiagnosticContext.Attachment>();
        for (DiagnosticContext diagnosticContext : diagnosticContexts) {
            DiagnosticContext.Attachment[] attachments = diagnosticContext.createAttachments();
            for (DiagnosticContext.Attachment attachment : attachments) {
                attachmentsList.add(attachment);
            }
        }
        if (attachmentsList.size() == 0) return null;

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(bos);
        zos.setLevel(ZipOutputStream.DEFLATED);

        for (DiagnosticContext.Attachment attachment : attachmentsList) {
            zos.putNextEntry(new ZipEntry(attachment.getName()));
            zos.write(attachment.getData());
        }

        String[] configRoots = Configuration.getConfigRootNames();
        for (String configRoot : configRoots) {
            try {
                String configXMLString = Configuration.getConfigXMLString(configRoot);
                long versionNumber = Configuration.getRoot(configRoot).getVersionNumber();
                if (configXMLString != null) {
                    zos.putNextEntry(new ZipEntry(configRoot + "." + versionNumber + ".xml"));
                    zos.write(configXMLString.getBytes());
                }
            } catch (IOException e) {
                log.warn("Could not find config file to include in diagnostic.", e);
            }
        }
        zos.close();

        return bos.toByteArray();
    }

    private byte[] zipFile(String fileName) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(bos);
        zos.setLevel(ZipOutputStream.DEFLATED);

        File file = new File(fileName);
        if (file.isFile() && file.canRead()) {
            zos.putNextEntry(new ZipEntry(file.getName()));
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));

            byte[] buffer = new byte[1024 * 100];
            int bytesRead;
            while ((bytesRead = bis.read(buffer)) != -1) {
                zos.write(buffer, 0, bytesRead);
            }
        } else {
            return null;
        }
        zos.close();
        return bos.toByteArray();
    }

    protected byte[] zipLogFiles() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(bos);
        zos.setLevel(ZipOutputStream.DEFLATED);

        String logDirStr = Log.getLogDirectory();
        File logDir = new File(logDirStr);
        if (!logDir.exists()) return null;
        File[] files = logDir.listFiles();
        if (files == null || files.length == 0) return null;
        for (File file : files) {
            if (file.isFile() && file.canRead()) {
                zos.putNextEntry(new ZipEntry(file.getName()));
                BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));

                byte[] buffer = new byte[1024 * 100];
                int bytesRead;
                while ((bytesRead = bis.read(buffer)) != -1) {
                    zos.write(buffer, 0, bytesRead);
                }
            }
        }

        zos.close();
        return bos.toByteArray();
    }

    /**
     * Will create an MBean server and register all MBeans provided by registered diagnostic contexts with it.
     * By default also starts HTML adaptor on a default port 1025.
     * <p/>
     * Configuration can be tweaked by putting following into application configuration file (application.xml)
     * <p/>
     * <propertyGroup key="JMX">
     * <propertyGroup key="htmlAdaptor">
     * <!-- Binds the HTML adaptor server to the first available port within the range -->
     * <property key="portRangeStart" value="1025"/>
     * <property key="portRangeEnd" value="65535"/>
     * </propertyGroup>
     * <propertyGroup key="jmxConnector">
     * <property key="port" value="4115"/>
     * </propertyGroup>
     * </propertyGroup>
     */
    public void createMBeanServer() {
        try {
            mBeanServer = MBeanServerFactory.createMBeanServer(Utilities.MBEANSERVER_DOMAIN);
            String applicationDiagnosticsObjectName = mBeanServer.getDefaultDomain() + ":type=" + ClassUtilities.getUnqualifiedClassName(ApplicationDiagnostics.class)
                    + ",applicationId=" + ApplicationInfo.getInstance().getId()
                    + ",environmentId=" + ApplicationInfo.getInstance().getEnvironmentId();
            if (log.isDebug())log.debug("Registering MBean: " + applicationDiagnosticsObjectName);
            mBeanServer.registerMBean(new ApplicationDiagnosticsMBeanAdaptor(), new ObjectName(applicationDiagnosticsObjectName));

            for (Object diagnosticContext1 : diagnosticContexts) {
                DiagnosticContext diagnosticContext = (DiagnosticContext) diagnosticContext1;
                registerMBeanForDiagnosticContext(diagnosticContext);
            }

            int portRangeStart = 1025;
            int portRangeEnd = 65535;
            PropertyGroup jmxProperties = ApplicationProperties.getApplicationProperties().getGroup("JMX");
            if (jmxProperties != null) {
                PropertyGroup htmlAdaptorProperties = jmxProperties.getGroup("htmlAdaptor");
                if (htmlAdaptorProperties != null) {
                    Number portRangeStartNumber = htmlAdaptorProperties.getNumericProperty("portRangeStart");
                    Number portRangeEndNumber = htmlAdaptorProperties.getNumericProperty("portRangeEnd");
                    if (portRangeStartNumber != null) portRangeStart = portRangeStartNumber.intValue();
                    if (portRangeEndNumber != null) portRangeEnd = portRangeEndNumber.intValue();
                }
                PropertyGroup jmxConnectorProperties = jmxProperties.getGroup("jmxConnector");
                if (jmxConnectorProperties != null) {
                    Number jmxConnectorPortNumber = jmxConnectorProperties.getNumericProperty("port");
                    if (jmxConnectorPortNumber != null) {
                        int jmxConnectorPort = jmxConnectorPortNumber.intValue();
                        try {
                            log.info("Binding JMXConnectorServer to port: " + jmxConnectorPort);
                            JMXConnectorServer connectorServer = JMXConnectorServerFactory.newJMXConnectorServer(new JMXServiceURL("jmxmp", null, jmxConnectorPort), null, mBeanServer);
                            connectorServer.start();
                        } catch (Exception e) {
                            log.error("Could not bind JMXConnectorServer to port: " + jmxConnectorPort, e);
                        }
                    }
                }
            }

            for (int port = portRangeStart; port < portRangeEnd; port++) {
                log.info("Binding diagnostics to port " + port);
                try {
                    HtmlAdaptorServer htmlAdaptor = new HtmlAdaptorServer(port);
                    htmlAdaptor.start();
                    while (htmlAdaptor.getState() == HtmlAdaptorServer.STARTING) Thread.sleep(100);
                    if (htmlAdaptor.isActive()) {
                        mBeanServer.registerMBean(htmlAdaptor, new ObjectName("Adaptor:name=html,port=" + port));
                        ApplicationInfo.getInstance().setDiagnosticPort(port);
                        mBeanServerHtmlAdaptorPort = port;
                        break;
                    }
                } catch (Exception e) {
                    log.info("Could not bind HtmlAdaptorServer to port: " + port);
                }
            }
        } catch (Exception e) {
            log.error(e);
        }
    }

    public int getMBeanServerHtmlAdaptorPort() {
        return mBeanServerHtmlAdaptorPort;
    }

    private void registerMBeanForDiagnosticContext(DiagnosticContext diagnosticContext) {
        if (mBeanServer == null) return;
        Object mBean = diagnosticContext.createMBean();
        if (mBean != null) {
            String mBeanName = ClassUtilities.getUnqualifiedClassName(mBean.getClass());
            if (log.isDebug())log.debug("Registering MBean: " + mBeanName);
            try {
                String mBeanIdentifier = diagnosticContext.getMBeanIdentifier();
                if (mBeanIdentifier == null) {
                    mBeanIdentifier = ":type=" + mBeanName;
                }
                mBeanServer.registerMBean(mBean, new ObjectName(mBeanServer.getDefaultDomain() + mBeanIdentifier));
            } catch (Exception e) {
                log.error(e);
            }
        }
    }

    public boolean isLogBeanToScreenDelays() {
        return logBeanToScreenDelays;
    }

    public void setLogBeanToScreenDelays(boolean logBeanToScreenDelays) {
        BeanPropertyChangeSupport.logEventTime = logBeanToScreenDelays;
        this.logBeanToScreenDelays = logBeanToScreenDelays;
    }

    public void setDebugLoggingEnabled(boolean selected) {
        Log.getCategory("org.bhavaya").setDebugOverride(selected);
        for (String logPackage : debugLogPackageList) {
            Log.getCategory(logPackage).setDebugOverride(selected);
        }
    }

    public boolean isDebugLoggingEnabled() {
        return Log.getCategory("org.bhavaya").isDebug();
    }

    public void sendLogFiles(String userComments) {
        String emailAddress = ApplicationProperties.getApplicationProperties().getMandatoryProperty("emailService.to");
        sendLogFilesToEmailAddress(userComments, emailAddress);
    }

    public void sendLogFiles(String userComments, String emailAddress) {
        String address = addDomainToEmail(emailAddress);
        sendLogFilesToEmailAddress(userComments, address);
    }

    private String addDomainToEmail(String emailAddress) {
        return emailAddress + ApplicationProperties.getApplicationProperties().getMandatoryProperty("emailService.defaultDomain");
    }

    private void sendLogFilesToEmailAddress(String userComments, String emailAddress) {
        try {
            String username = ApplicationInfo.getInstance().getUsername();
            String subject = ApplicationInfo.getInstance().getName() + ": Log Files: environment: "
                    + ApplicationInfo.getInstance().getEnvironmentName() + ", username: " + username;
            Message mailMessage = EmailUtilities.getDefaultMimeMessage(new String[] {emailAddress}, subject);

            MimeBodyPart logAttachment = null;
            byte[] data = zipLogFiles();
            if (data != null && data.length > 0) {
                logAttachment = new MimeBodyPart();
                logAttachment.setDataHandler(new DataHandler(new EmailUtilities.ByteArrayDataSource(data, "application/zip")));
                logAttachment.setFileName("logs_" + username + ".zip");
            }

            MimeBodyPart summaryBodyPart = new MimeBodyPart();
            summaryBodyPart.setContent(createSendLogFilesReport(userComments, logAttachment != null), "text/html");
            summaryBodyPart.setHeader("Content-Type", "text/html; charset=iso-8859-1");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(summaryBodyPart);
            if (logAttachment != null) multipart.addBodyPart(logAttachment);

            mailMessage.setContent(multipart);
            EmailUtilities.sendMessage(mailMessage);
            log.info("Sent log files to: " + emailAddress);
        } catch (Throwable t) {
            log.error("Unable to send log files", t);
        }
    }

    public static class LoggingEventBean {
        private LoggingEvent loggingEvent;

        public LoggingEventBean(LoggingEvent loggingEvent) {
            this.loggingEvent = loggingEvent;
        }

        public Date getTimestamp() {
            return new Date(loggingEvent.timeStamp);
        }

        public String getThreadName() {
            return loggingEvent.getThreadName();
        }

        public String getLevel() {
            if (loggingEvent.level == null) return null;
            return loggingEvent.level.toString();
        }

        public String getCategory() {
            if (loggingEvent.categoryName == null) return null;
            int lastDot = loggingEvent.categoryName.lastIndexOf('.');
            if (lastDot == -1 || ((lastDot + 1) > (loggingEvent.categoryName.length() - 1))) return loggingEvent.categoryName;
            return loggingEvent.categoryName.substring(lastDot + 1);
        }

        public String getMessage() {
            return loggingEvent.getRenderedMessage();
        }

        public String[] getThrowableStrings() {
            return loggingEvent.getThrowableStrRep();
        }

        public Throwable getThrowable() {
            if (loggingEvent.getThrowableInformation() == null) return null;
            return loggingEvent.getThrowableInformation().getThrowable();
        }

        public LoggingEvent getLoggingEvent() {
            return loggingEvent;
        }

        public String toString() {
            return getMessage();
        }
    }

    protected class LogListener implements Log.Listener {
        private boolean headless;

        public LogListener(boolean headless) {
            this.headless = headless;
        }

        public void logMessage(final LoggingEvent loggingEvent) {
            if (headless) {
                logMessageInternal(loggingEvent);
            } else {
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        logMessageInternal(loggingEvent);
                    }
                });
            }
        }

        private void logMessageInternal(LoggingEvent loggingEvent) {
            if (loggingEvent == null) return; // just in case
            LoggingEventBean loggingEventBean = new LoggingEventBean(loggingEvent);

            addLoggingEventBean(loggingEventBean, allLogStatements, false);

            if (loggingEvent.level.equals(Priority.WARN)) {
                addLoggingEventBean(loggingEventBean, warnLogStatements, true);
            }
            if (loggingEvent.level.isGreaterOrEqual(Priority.ERROR)) {
                addLoggingEventBean(loggingEventBean, errorLogStatements, true);

                if (loggingEventBean.getThrowable() != null) {
                    addLoggingEventBean(loggingEventBean, exceptionLogStatements, true);
                }
            }
        }

        private void addLoggingEventBean(ApplicationDiagnostics.LoggingEventBean loggingEventBean, java.util.List list, boolean keepHead) {
            synchronized (list) {
                // Event driven stack, although we could end up in this loop for ages if we are logging at an incredible rate, hence add a Thread.yield
                while (list.size() >= MAX_LOG_MESSAGES) {
                    int indexToRemove = keepHead ? MAX_HEAD_LOG_MESSAGES_TO_KEEP - 1 : MAX_LOG_MESSAGES - 1;
                    list.remove(indexToRemove);
                    Thread.yield();
                }

                list.add(0, loggingEventBean);
            }
        }
    }
}
