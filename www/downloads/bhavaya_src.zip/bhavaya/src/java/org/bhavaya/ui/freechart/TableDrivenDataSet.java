package org.bhavaya.ui.freechart;

import org.jfree.data.general.DatasetChangeListener;
import org.jfree.data.general.DatasetGroup;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.bhavaya.util.WeakReferenceTimer;

import javax.swing.table.TableModel;
import javax.swing.event.TableModelListener;
import javax.swing.event.TableModelEvent;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Set;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: Nick Ebbutt
 * Date: 22-Feb-2008
 * Time: 11:43:39
 *
 * A superclass for table driven data sets, used to provide source data for a JFreeChart
 * Adds functionality to subscribe to TableModelUpdates and notify subclasses when the data in the source
 * TableModel has changed. This notification is delayed/throttled since it is not a good
 * idea to try to recalculate & repaint the chart for every update in the table model.
 *
 * Updates from the source table model are placed into three categories:
 * - 1. updates affecting the series/categories. Typically these require the whole dataset to be regenerated
 * - 2. updates to values only. This may require just the values to be refreshed in the chart dataset
 * - 3. updates which have no effect on the chart, no action required!
 *
 * For this to work correctly, it is necessary to set the columns which are used by the chart for
 * series/categories in the dataset, and for values
 */
public abstract class TableDrivenDataSet implements TableModelListener, Dataset {

    private int[] categoryColumns = new int[0]; //updates to these require a DataSet refresh
    private int[] valueColumns = new int[0];    //updates to these require a repaint of the chart only

    private int scheduledUpdateType;
    private static final int REDRAW_CHART_FLAG = 1;
    private static final int UPDATE_DATASET_FLAG = 2;
    private boolean timerStarted;
    private int timerDelay = 2000;

    //must hold a reference to this to prevent it being garbage collected when wrapped as a weak reference listener
    private TableUpdatesTimerListener timerListener = new TableUpdatesTimerListener();

    private Set<DatasetChangeListener> changeListeners = new HashSet<DatasetChangeListener>();
    private DatasetGroup datasetGroup;

    public TableDrivenDataSet(TableModel tableModel) {
        tableModel.addTableModelListener(this);
    }

    public void setValueColumns(int[] valueColumns) {
        this.valueColumns = valueColumns;
    }

    public void setCategoryColumns(int[] categoryColumns) {
        this.categoryColumns = categoryColumns;
    }

    public void tableChanged(TableModelEvent e) {
        startUpdateTimer();
        switch ( e.getType() ) {

            //everything other than update requires a dataset recalc
            case ( TableModelEvent.UPDATE ) :
                if ( e.getFirstRow() == TableModelEvent.HEADER_ROW ) {
                    setDataSetUpdateRequired();
                }
                else {
                    processColumnUpdate(e.getColumn());
                }
                break;
            default :
                setDataSetUpdateRequired();
        }
    }

    private void startUpdateTimer() {
        if ( ! timerStarted ) {
            Timer updateTimer = WeakReferenceTimer.createTimer(timerDelay, timerListener);
            updateTimer.setRepeats(true);
            updateTimer.start();
            timerStarted = true;
        }
    }

    private class TableUpdatesTimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if ( (scheduledUpdateType & UPDATE_DATASET_FLAG ) > 0 ) {
                categoriesChanged();
            }
            else if ((scheduledUpdateType & UPDATE_DATASET_FLAG ) > 0 ) {
                valuesChanged();
            }
            scheduledUpdateType = 0;
        }
    }

    /**
     * Values used by the chart have changed
     */
    abstract void valuesChanged();

    /**
     * The series / categories for the chart have changed.
     */
    abstract void categoriesChanged();



    private void processColumnUpdate(int col) {
        if ( col == TableModelEvent.ALL_COLUMNS) {
            setDataSetUpdateRequired();
        }
        else if ( isCategoryColumn(col)) {
            setDataSetUpdateRequired();
        }
        else if ( isValueColumn(col)) {
            setRedrawUpdateRequired();
        }
    }

    private boolean isValueColumn(int column) {
        return containsCol(valueColumns, column);
    }

    private boolean isCategoryColumn(int column) {
        return containsCol(categoryColumns, column);
    }

    private boolean containsCol(int[] columns, int colToFind) {
        boolean found = false;
        for ( int col : columns ) {
            if ( col == colToFind ) {
                found = true;
                break;
            }
        }
        return found;
    }

    private void setDataSetUpdateRequired() {
        scheduledUpdateType |= UPDATE_DATASET_FLAG;
    }

    private void setRedrawUpdateRequired() {
        scheduledUpdateType |= REDRAW_CHART_FLAG;
    }

    protected void fireDatasetChanged() {
        DatasetChangeEvent changeEvent = new DatasetChangeEvent(this, this);
        for (DatasetChangeListener datasetChangeListener : changeListeners ) {
            datasetChangeListener.datasetChanged(changeEvent);
        }
    }

    //////////////////////////////////////////////
    // DataSet methods

    public void addChangeListener(DatasetChangeListener listener) {
        changeListeners.add(listener);
    }

    public void removeChangeListener(DatasetChangeListener listener) {
        changeListeners.remove(listener);
    }

    public DatasetGroup getGroup() {
        return datasetGroup;
    }

    public void setGroup(DatasetGroup group) {
        datasetGroup = group;
    }

}
