package org.bhavaya.ui.freechart.builder;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartFactory;
import org.bhavaya.ui.table.BeanCollectionTableModel;
import org.bhavaya.ui.table.AnalyticsTableModel;
import org.bhavaya.ui.table.KeyedColumnTableModel;
import org.bhavaya.ui.freechart.ChartViewConfiguration;
import org.bhavaya.ui.freechart.TableXYDataSet;
import org.bhavaya.collection.BeanCollection;

/**
 * Created by IntelliJ IDEA.
 * User: Nick Ebbutt
 * Date: 25-Feb-2008
 * Time: 14:28:11
 */
public class TimeSeriesChartBuilder implements ChartBuilder {

    public AnalyticsTableModel buildTableModel(ChartViewConfiguration chartViewConfiguration, BeanCollection beanCollection) {
        String[] seriesKeyColumns = chartViewConfiguration.getGroupColumns();
        String xColumn = chartViewConfiguration.getXValuesColumn();
        String yColumn = chartViewConfiguration.getYValuesColumn();

        BeanCollectionTableModel beanCollectionTableModel = new BeanCollectionTableModel(beanCollection, false);
        for ( String columnName : seriesKeyColumns ) {
            beanCollectionTableModel.addColumnLocator(columnName);
        }
        beanCollectionTableModel.addColumnLocator(xColumn);
        beanCollectionTableModel.addColumnLocator(yColumn);

        AnalyticsTableModel analyticsModel = new AnalyticsTableModel(beanCollectionTableModel);
        analyticsModel.addSortingColumn(xColumn, false);
        return analyticsModel;
    }

    public JFreeChart buildChart(ChartViewConfiguration chartViewConfiguration, KeyedColumnTableModel keyedTableModel) {
        String[] seriesKeyColumns = chartViewConfiguration.getGroupColumns();
        String xColumn = chartViewConfiguration.getXValuesColumn();
        String yColumn = chartViewConfiguration.getYValuesColumn();
        String title = chartViewConfiguration.getChartTitle();
        String timeAxisLabel = chartViewConfiguration.getTimeAxisLabel();
        String valueAxisLabel = chartViewConfiguration.getValueAxisLabel();
        boolean showLegend = chartViewConfiguration.isShowLegend();
        boolean showTooltips = chartViewConfiguration.isShowTooltips();
        boolean generateURLs = chartViewConfiguration.isGenerateURLs();

        TableXYDataSet tableXYDataSet = new TableXYDataSet(keyedTableModel, seriesKeyColumns, xColumn, yColumn);
        return ChartFactory.createTimeSeriesChart(
            title,
            timeAxisLabel,
            valueAxisLabel,
            tableXYDataSet,
            showLegend,
            showTooltips,
            generateURLs
        );
    }
}
