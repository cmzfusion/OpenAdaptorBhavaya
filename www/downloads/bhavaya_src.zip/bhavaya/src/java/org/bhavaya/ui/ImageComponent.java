package org.bhavaya.ui;

import org.bhavaya.util.IOUtilities;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Description
 *
 * @author Brendon McLean
 * @version $Revision: 1.2 $
 */
public class ImageComponent extends JPanel {
    private BufferedImage image;

    public ImageComponent(String resourceName) {
        super(false);
        try {
            image = ImageIO.read(IOUtilities.getResourceAsStream(resourceName));
        } catch (IOException e) {
        }
    }

    public Dimension getPreferredSize() {
        return new Dimension(image.getWidth(), image.getHeight());
    }

    public void paint(Graphics g) {
        super.paint(g);
        g.drawImage(image, (getWidth() - image.getWidth()) / 2, (getHeight() - image.getHeight()) / 2, this);
    }
}
