package org.bhavaya.ui.freechart;

import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: Nick Ebbutt
 * Date: 25-Feb-2008
 * Time: 11:52:50
 *
 * Each chart type requires a different set of configuration properties.
 * We could handle this by creating different subclasses of an abstract ChartViewConfiguration superclass,
 * each with the correct set of fields - but we would end up with a large number or subclasses.
 * Another possible solution would be to have one config class with fields to hold the superset of all properties.
 * Yet another alternative is to wrap a Properties instance or Map to store the properties, like this initial implementation
 *
 * I think using the Properties approach has some possible advantages, among these -
 * - inherit the equals and hashcode implementation
 * - inherit the shallow clone implementation, which is guaranteed safe since String properties are immutable,
 *   this can be used to take a snapshot of state which is useful to rollback changes etc.
 * - possible serialization to properties file for persistence (as well as compatibility with bean persistence)
 * - more resilient to changes in config parameters, will not crash if somebody has an outdated property in their config
 */
public class ChartViewConfiguration  {

    //don't provide access to the Properties map directly -
    //in case we want to change the implementation in the future to store the config as fields
    private Properties configurationProperties = new Properties();

    private static final String CHART_TYPE_KEY = "ChartType";
    private static final String GROUP_COLUMN_NAMES_KEY = "GroupColumns";
    private static final String X_VALUES_COLUMN_KEY = "XValuesColumn";
    private static final String Y_VALUES_COLUMN_KEY = "YValuesColumn";
    private static final String CHART_TITLE_KEY = "ChartTitle";
    private static final String TIME_AXIS_LABEL_KEY = "TimeAxisLabel";
    private static final String VALUE_AXIS_LABEL_KEY = "ValueAxisLabel";
    private static final String SHOW_LEGEND_KEY = "ShowLegend";
    private static final String SHOW_TOOLTIPS_KEY = "ShowTooltips";
    private static final String GENERATE_URLS_KEY = "GenerateURLs";

    public void setChartType(ChartType chartType) {
        configurationProperties.setProperty(CHART_TYPE_KEY, chartType.name());
    }

    public ChartType getChartType() {
        return ChartType.valueOf(configurationProperties.getProperty(CHART_TYPE_KEY));
    }

    public String[] getGroupColumns() {
        return getAsStringArray(GROUP_COLUMN_NAMES_KEY);
    }

    public void setGroupColumns(String... columns) {
        putAsStringArray(GROUP_COLUMN_NAMES_KEY, columns);
    }

    public String getXValuesColumn() {
        return configurationProperties.getProperty(X_VALUES_COLUMN_KEY);
    }

    public void setXValuesColumn(String columnName) {
        configurationProperties.setProperty(X_VALUES_COLUMN_KEY, columnName);
    }

    public String getYValuesColumn() {
        return configurationProperties.getProperty(Y_VALUES_COLUMN_KEY);
    }

    public void setYValuesColumn(String columnName) {
        configurationProperties.setProperty(Y_VALUES_COLUMN_KEY, columnName);
    }

    public String getChartTitle() {
        return configurationProperties.getProperty(CHART_TITLE_KEY);
    }

    public void setChartTitle(String chartTitle) {
        configurationProperties.setProperty(CHART_TITLE_KEY, chartTitle);
    }

    public String getTimeAxisLabel() {
        return configurationProperties.getProperty(TIME_AXIS_LABEL_KEY);
    }

    public void setTimeAxisLabel(String label) {
        configurationProperties.setProperty(TIME_AXIS_LABEL_KEY, label);
    }

    public String getValueAxisLabel() {
        return configurationProperties.getProperty(VALUE_AXIS_LABEL_KEY);
    }

    public void setValueAxisLabel(String value) {
        configurationProperties.setProperty(VALUE_AXIS_LABEL_KEY, value);
    }

    public boolean isShowLegend() {
        return Boolean.valueOf(configurationProperties.getProperty(SHOW_LEGEND_KEY, "false"));
    }

    public void setShowLegend(boolean isShowLegend) {
        configurationProperties.setProperty(SHOW_LEGEND_KEY, String.valueOf(isShowLegend));
    }

    public boolean isShowTooltips() {
        return Boolean.valueOf(configurationProperties.getProperty(SHOW_TOOLTIPS_KEY, "false"));
    }

    public void setShowTooltips(boolean isShowTooptips) {
        configurationProperties.setProperty(SHOW_TOOLTIPS_KEY, String.valueOf(isShowTooptips));
    }

     public boolean isGenerateURLs() {
        return Boolean.valueOf(configurationProperties.getProperty(GENERATE_URLS_KEY, "false"));
    }

    public void setGenerateURLs(boolean isGenerateURLs) {
        configurationProperties.setProperty(GENERATE_URLS_KEY, String.valueOf(isGenerateURLs));
    }

    /**
     * @return a comma separated string property as a String[]
     */
    private String[] getAsStringArray(String property) {
        String columns = configurationProperties.getProperty(property);
        return (columns == null ) ? new String[0] : columns.split(",");
    }

     /**
     * Store a String[] as a comma separated string property
     * Does not support the case where the String values to be stored already contain commas
     */
    private void putAsStringArray(String property, String[] values) {
        StringBuilder sb = new StringBuilder();
        for ( String col : values ) {
            if ( sb.length() > 0 ) {
                sb.append(",");
            }
            sb.append(col);
        }
        configurationProperties.setProperty(property, sb.toString());
    }

    public int hashcode() {
        return configurationProperties.hashCode();
    }

    public boolean equals(Object o ) {
        boolean result = false;
        if ( o instanceof ChartViewConfiguration ) {
            result = ((ChartViewConfiguration)o).configurationProperties.equals(configurationProperties);
        }
        return result;
    }

    public static enum ChartType {
        timeSeriesChart
    }

}
