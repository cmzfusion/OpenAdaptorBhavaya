package org.bhavaya.ui.freechart;

import org.bhavaya.ui.table.KeyedColumnTableModel;
import org.bhavaya.ui.table.CachedObjectGraph;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.DomainOrder;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: Nick Ebbutt
 * Date: 22-Feb-2008
 * Time: 11:14:00
 * <pre>
 * This class adapts a KeyedColumnTableModel to the XYDataSet interface
 *
 * Unlike GroupedXYDataSet, this class contains no logic to try to guess the
 * source columns for X and Y values etc. Instead the following source columns must be set explicitly:
 *
 * - The column(s) from the KeyedColumnTableModel which are taken in combination to generate a series key
 * - The numeric or date column used to generate the X value
 * - The numeric column used to generate the Y value
 * </pre>
 */
public class TableXYDataSet extends TableDrivenDataSet implements XYDataset {
    
    private KeyedColumnTableModel keyedColumnTableModel;
    private String[] seriesColumns;
    private String xValueColumn;
    private String yValueColumn;
    private int[] seriesKeyColIndexes;
    private int xValColumnIndex;
    private int yValColumnIndex;

    private List<List<SeriesItem>> seriesItems = new ArrayList<List<SeriesItem>>();
    private List<String> seriesKeys = new ArrayList<String>();

    //a fast way of finding the index for a given series name without iterating the list
    private Map<String, Integer> seriesKeyToIndex = new HashMap<String,Integer>();

    public TableXYDataSet(KeyedColumnTableModel keyedColumnTableModel, String[] seriesColumns, String xValueColumn, String yValueColumn) {
        super(keyedColumnTableModel);
        this.keyedColumnTableModel = keyedColumnTableModel;
        this.seriesColumns = seriesColumns;
        this.xValueColumn = xValueColumn;
        this.yValueColumn = yValueColumn;

        initChart();
    }
    
    private void initChart() {
        try {
            clearDataSetState();
            findColumnIndices();
            buildSeriesGroupMap();

            //columns which if changes mean we need to update the series x/y values
            setValueColumns(new int[] { xValColumnIndex, yValColumnIndex});

            //columns which if changed mean we need to recalc the whole dataset
            setCategoryColumns(seriesKeyColIndexes);

        } catch (InvalidColumnException e) {
            e.printStackTrace();
        }
    }

    private void clearDataSetState() {
        seriesItems.clear();
        seriesKeys.clear();
        seriesKeyToIndex.clear();
    }

    private void buildSeriesGroupMap() {
        StringBuilder stringBuilder = new StringBuilder();
        for ( int row=0; row < keyedColumnTableModel.getRowCount(); row ++ ) {
            stringBuilder.setLength(0);
            String groupName = calculateGroupNameForRow(stringBuilder, row);
            addRowIndexToSeriesForGroup(groupName, row);
        }
    }

    private void addRowIndexToSeriesForGroup(String groupName, int row) {
        if ( groupName.length() > 0) {
            getListOfItemsForSeries(groupName).add(new SeriesItem(row));
        }
    }

    private String calculateGroupNameForRow(StringBuilder stringBuilder, int row) {
        Object o;
        for ( int seriesCol : seriesKeyColIndexes) {
            o = keyedColumnTableModel.getValueAt(row, seriesCol );
            if ( o != null && o != CachedObjectGraph.DATA_NOT_READY) {
                stringBuilder.append(o.toString());
            }
        }
        return stringBuilder.toString();
    }

    private List<SeriesItem> getListOfItemsForSeries(String groupName) {
        List<SeriesItem> list;
        Integer groupIndex = seriesKeyToIndex.get(groupName);
        if ( groupIndex == null ) {
            seriesKeyToIndex.put(groupName, seriesKeyToIndex.size());
            list = new ArrayList<SeriesItem>();
            seriesItems.add(list);
            seriesKeys.add(groupName);
        } else {
            list = seriesItems.get(groupIndex);
        }
        return list;
    }

    private void findColumnIndices() throws InvalidColumnException {
        seriesKeyColIndexes = new int[seriesColumns.length];
        for ( int loop=0; loop < seriesColumns.length; loop ++ ) {
            seriesKeyColIndexes[loop] = findColumnIndex(seriesColumns[loop]);
        }
        xValColumnIndex = findColumnIndex(xValueColumn);
        yValColumnIndex = findColumnIndex(yValueColumn);
    }

    private int findColumnIndex(String columnName) throws InvalidColumnException {
        int index = keyedColumnTableModel.getColumnIndex(columnName);
        if ( index == -1 ) {
            throw new InvalidColumnException(columnName);
        }
        return index;
    }

    void valuesChanged() {
        refreshSeriesItemValues();
        fireDatasetChanged();
    }

    void categoriesChanged() {
        initChart();
        fireDatasetChanged();
    }

    //refresh the values of each series item with the data from the table model
    private void refreshSeriesItemValues() {
        for ( List<SeriesItem> seriesList : seriesItems) {
            for ( SeriesItem item : seriesList) {
                item.refreshValuesFromTableModel();
            }
        }
    }

    private static class InvalidColumnException extends Exception {
        public InvalidColumnException(String columnName) {
            super("Could not find column " + columnName);
        }
    }

    //////////////////////////////////////////
    //XYDataSet methods

    public DomainOrder getDomainOrder() {
        return DomainOrder.ASCENDING;  //will need to take from chartviewconfig later
    }

    public int getItemCount(int series) {
        return seriesItems.get(series).size();
    }

    public Number getX(int series, int item) {
        return seriesItems.get(series).get(item).getXValue();
    }

    public double getXValue(int series, int item) {
        return seriesItems.get(series).get(item).getXValue().doubleValue();
    }

    public Number getY(int series, int item) {
        return seriesItems.get(series).get(item).getYValue();
    }

    public double getYValue(int series, int item) {
        return seriesItems.get(series).get(item).getYValue().doubleValue();
    }


    //////////////////////////////////////////
    //SeriesDataSet methods

    public int getSeriesCount() {
        return seriesItems.size();
    }

    public Comparable getSeriesKey(int series) {
        return seriesKeys.get(series);
    }

    public int indexOf(Comparable seriesKey) {
        return seriesKeyToIndex.get(seriesKey);
    }

    //holds the x/y data for a single item in a series
    //n.b. this is a cached copy of the values in the underlying table model
    //this is because the chart update is delayed for performance reasons, so the data displayed by the chart is behind the
    //data in the table model. In the interim periods beteen chart updates we need to keep the chart data consistent
    private class SeriesItem {
        private Number xValue;
        private Number yValue;
        private int sourceRow;

        private SeriesItem(int sourceRow) {
            this.sourceRow = sourceRow;
            refreshValuesFromTableModel();
        }

        protected void refreshValuesFromTableModel() {
            xValue = getNumberForObject(keyedColumnTableModel.getValueAt(sourceRow, xValColumnIndex));
            yValue = getNumberForObject(keyedColumnTableModel.getValueAt(sourceRow, yValColumnIndex));
        }

        public Number getXValue() {
            return xValue;
        }

        public Number getYValue() {
            return yValue;
        }

        public int getSourceRow() {
            return sourceRow;
        }

        private Number getNumberForObject(Object o) {
            if (o instanceof Number) {
                return (Number) o;
            } else if (o instanceof java.sql.Date) {
                java.sql.Date date = (java.sql.Date) o;
                return new Long(date.getTime());
            } else if (o instanceof java.util.Date) {
                java.util.Date date = (java.util.Date) o;
                return new Long(date.getTime());
            }
            return new Double(0.0);
        }
    }
}
