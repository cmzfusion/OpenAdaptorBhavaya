package org.bhavaya.ui.table;


/**
 * Created by IntelliJ IDEA.
 * User: dhayatd
 * Date: 18-Sep-2007
 * Time: 11:29:08
 * To change this template use File | Settings | File Templates.
 */
public interface CustomColumnNameModel {

    public String getCustomColumnName(int column);
}
