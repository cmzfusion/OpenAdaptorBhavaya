package org.bhavayademo.beans;

/**
 * @author Parwinder Sekhon
 * @version $Revision: 1.2 $
 */
public abstract class Rating extends org.bhavaya.beans.Bean  {
}
